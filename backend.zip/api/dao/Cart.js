const util = require('util')
const mysql = require('mysql')
const db = require('../db')

module.exports.getCartByUserId = function (userId, callback) {
    let sql = 'SELECT * FROM cart WHERE userId = ?'
    db.query(sql, [userId], (err, response) => {
        if (err) throw err
        // thu ko return => ra bug do no ko trả về mà chạy tiếp
        return callback(err,response);
    })
    //return callback(err,response);
}
module.exports.createCart = function (cartObj, callback) {
    var values = [
        // phai giong voi ten truong trong db
        [cartObj.totalQty, cartObj.totalPrice,cartObj.userId,cartObj.items],
      ];
    
    var sql = "INSERT INTO cart (totalQty, totalPrice,userId,items) VALUES ?";
    db.query(sql,  [values],function (err, result) {
        if (err) throw err;
        console.log("1 record inserted");
        return callback(err,result);
    });
}