'use strict'
const jwt = require('jsonwebtoken')
let User = require('../dao/User');
let Cart = require('../dao/Cart');
let Product = require('../dao/Products');
const config = require('../configs/jwt-config')
const CartClass = require('../modules/Cart')

module.exports = {
    get: (req, res,next) => {
        const { email, password } = req.body.credential || {}
        if (!email || !password) {
            let err = new TypedError('login error', 400, 'missing_field', { message: "missing username or password" })
            return next(err)
        }
        
        User.getUserByEmail(email, function (err, user) {
            if (err) return next(err)
            if (!user) {
                let err = new TypedError('login error', 403, 'invalid_field', { message: "Incorrect email or password" })
                return next(err)
            }
            User.comparePassword(password, user[0].password, function (err, isMatch) {
                if (err) return next(err)
                if (isMatch) {
                    let token = jwt.sign({ email: email },config.secret,{ expiresIn: '7d' })
                    res.status(201).json({
                        user_token: {
                        user_id: user[0].id,
                        user_name: user[0].fullname,
                        token: token,
                        expire_in: '7d'
                        }
                    })
                } else {
                    let err = new TypedError('login error', 403, 'invalid_field', { message: "Incorrect email or password" })
                    return next(err)
                }
            })
        })
    },

    signin: (req, res,next) => {
        const { fullname, email, password, verifyPassword } = req.body
        if(password!==verifyPassword){
            return next("password ko giong nhau")
        }
        // check mail da co chua
        User.getUserByEmail(email, function (error, user) {
            if (error) return next(error)
            if (0 < user.length) {
                // TODO
                // xu lý báo rằng địa chỉ mail này đã được sử dụng
                //let err = new TypedError('signin error', 409, 'invalid_field', {
                //    message: "user is existed"
                //})
                return next(error)
            }
            console.log("check xong");
            // luu vao db
            User.createUser(fullname,email,password, function (err, user) {
                if (err) return next(err);
                return res.json({ message: 'user created' })
            })
        })
    },
    cartsInsert:(req, res,next) => {
        let userId = req.params.userId
        let { productId, increase, decrease } = req.body

        Cart.getCartByUserId(userId, function (err, c) {
            if (err) return next(err)
            let oldCart = new CartClass(c[0] || { userId })
            // no cart save empty cart to database then return response
            console.log(oldCart);
            //if (c.length < 1 && !productId) {
            if (!c.length) {
                return Cart.createCart(oldCart, function (err, resultCart) {
                    if (err) return next(err)
                    
                    return res.status(201).json({ cart: resultCart })
                })
            }
            
            Product.findById(productId, function (e, product) {
            if (e) {
                e.status = 406;
                return next(e);
            }
            if (product) {
                if (decrease) {
                    oldCart.decreaseQty(product.id);
                } else if (increase) {
                    oldCart.increaseQty(product.id);
                } else {
                    oldCart.add(product, product.id);
                }
                let newCart = oldCart.generateModel()
                Cart.updateCartByUserId(
                userId,
                newCart,
                function (err, result) {
                    if (err) return next(err)
                    return res.status(200).json({ cart: result })
                })
            } else {
                // apply variant
                Variant.getVariantByID(productId, function (e, variant) {
                if (e) {
                    e.status = 406;
                    return next(e);
                }
                if (variant) {
                    Product.getProductByID(variant.productID, function (e, p) {
                    let color = (variant.color) ? "- " + variant.color : "";
                    let size = (variant.size) ? "- " + variant.size : "";
                    variant.title = p.title + " " + color + size
                    variant.price = p.price
                    if (decrease) {
                        oldCart.decreaseQty(variant.id);
                    } else if (increase) {
                        oldCart.increaseQty(variant.id);
                    } else {
                        oldCart.add(variant, variant.id);
                    }
                    let newCart = oldCart.generateModel()
                    Cart.updateCartByUserId(
                        userId,
                        newCart,
                        function (err, result) {
                        if (err) return next(err)
                        res.status(200).json({ cart: result })
                        })
                    })
                }
                // no product and no variant find
                else {
                    let err = new TypedError('/cart', 400, 'invalid_field', {
                    message: "invalid request body"
                    })
                    return next(err)
                }
                })
            }
            })
        })
    },
    cartsdetail:(req, res,next) => {
        let userId = req.params.userId
        Cart.getCartByUserId(userId, function (err, cart) {
            if (err) return next(err)
            if (cart.length < 1) {
            let err = new TypedError('cart error', 404, 'not_found', { message: "create a cart first" })
            return next(err)
            }
            return res.json({ cart: cart[0] })
        })
    }
        
}